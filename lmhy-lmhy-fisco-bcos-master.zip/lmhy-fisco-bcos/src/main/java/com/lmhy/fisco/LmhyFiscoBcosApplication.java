package com.lmhy.fisco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmhyFiscoBcosApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmhyFiscoBcosApplication.class, args);
	}
}
